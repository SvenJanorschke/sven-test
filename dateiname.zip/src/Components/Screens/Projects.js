import React from "react";
import Footer from "../Containers/Footer/Footer";
import AllProjects from "../Containers/AllProjects/AllProjects";
const Projects = () => {
  return (
    <div>
      <AllProjects />
      <Footer />
    </div>
  );
};

export default Projects;
