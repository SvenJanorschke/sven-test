import React from "react";

const sourceContent = () => {
  return (
    <div class="container">
      <h1>Soon we will update data</h1>
    </div>
  );
};

export default sourceContent;
